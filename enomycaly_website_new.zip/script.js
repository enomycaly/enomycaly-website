function openOrder(){
document.getElementById("order").scrollIntoView();
}

function submitForm(e){
e.preventDefault();
alert("Order received! We will contact you soon.");
}
